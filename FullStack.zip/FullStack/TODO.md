# Smart Campus Event Management System - Development TODO

## Overall Plan Summary
**Goal**: Build a full-stack Spring Boot application for campus event management with student and admin features using Spring Core, MVC, Data JPA, Thymeleaf, validation, security, exception handling.

**Tech Stack**:
- Backend: Spring Boot 3.x, Spring MVC, Spring Data JPA, Spring Security (basic auth), Hibernate
- Database: H2 (in-memory for demo, easy setup)
- Frontend: Thymeleaf, HTML5/CSS3, Bootstrap for styling
- Validation: Bean Validation (JSR-303)
- Other: @ControllerAdvice for exceptions

**Directory Structure**:
```
smart-campus-events/
├── src/main/java/com/campus/events/
│   ├── SmartCampusEventsApplication.java
│   ├── config/
│   │   ├── SecurityConfig.java
│   │   └── JpaConfig.java
│   ├── controller/
│   │   ├── StudentController.java
│   │   └── AdminController.java
│   ├── entity/
│   │   ├── Event.java
│   │   └── Registration.java
│   ├── repository/
│   │   ├── EventRepository.java
│   │   └── RegistrationRepository.java
│   ├── service/
│   │   ├── EventService.java
│   │   └── RegistrationService.java
│   └── exception/
│       └── GlobalExceptionHandler.java
├── src/main/resources/
│   ├── templates/
│   │   ├── student/
│   │   │   ├── events.html
│   │   │   ├── register.html
│   │   │   └── my-registrations.html
│   │   └── admin/
│   │       ├── events.html
│   │       ├── add-event.html
│   │       ├── edit-event.html
│   │       └── statistics.html
│   ├── static/
│   │   ├── css/
│   │   │   └── style.css
│   │   └── js/
│   └── application.properties
├── pom.xml
└── README.md
```

**Key Features Implementation**:
- Student: Browse events (list), register (form validation), view registrations
- Admin: CRUD events, search/filter (date/dept/type), statistics (counts/aggregates)
- Security: Basic auth for admin
- REST APIs: For AJAX/event data
- Validation: @NotNull, @Size, etc.
- MVC Pages: Thymeleaf templates

## Step-by-Step Implementation Plan

### Phase 1: Project Setup (Steps 1-3)
- [ ] 1. Create `pom.xml` with Spring Boot starter dependencies (web, data-jpa, security, thymeleaf, h2)
- [ ] 2. Create main application class `SmartCampusEventsApplication.java`
- [ ] 3. Create `application.properties` (H2 config, JPA settings)

### Phase 2: Domain & Data Layer (Steps 4-8)
- [ ] 4. Create `Event.java` entity (@Entity, fields: id, title, description, date, department, type, capacity)
- [ ] 5. Create `Registration.java` entity (@Entity, fields: id, eventId, studentName, studentEmail)
- [ ] 6. Create `EventRepository` (JpaRepository + custom queries for search/filter)
- [ ] 7. Create `RegistrationRepository` (JpaRepository + stats queries)
- [ ] 8. Create services: `EventService`, `RegistrationService` (business logic, DI)

### Phase 3: Controllers & Security (Steps 9-12)
- [ ] 9. Create `StudentController` (MVC for browse/register/view registrations)
- [ ] 10. Create `AdminController` (CRUD, search, stats - protected)
- [ ] 11. Create `SecurityConfig` (basic auth for /admin/**)
- [ ] 12. Create `GlobalExceptionHandler` (@ControllerAdvice)

### Phase 4: Frontend (Steps 13-20)
- [ ] 13. Create base layout `templates/layout.html`
- [ ] 14-17. Student templates: events.html, register.html, my-registrations.html
- [ ] 18-20. Admin templates: events.html (list/search), add-event.html, edit-event.html, statistics.html
- [ ] 21. Create `static/css/style.css` (Bootstrap + custom)
- [ ] 22. Create `README.md` with run instructions

### Phase 5: Testing & Completion (Steps 23-25)
- [ ] 23. Test all features locally
- [ ] 24. Add sample data (CommandLineRunner or data.sql)
- [ ] 25. Complete task with run command

**Current Progress**: Ready to start Phase 1.

**Next Action**: Confirm this plan before creating files. Do you approve this structure and steps? Any changes to tech stack, database (H2 ok for demo?), or features?

