
echo Starting Smart Campus Events...
echo This downloads Maven wrapper (first time OK)
call mvnw.cmd clean spring-boot:run
pause

