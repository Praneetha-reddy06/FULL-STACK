@echo off
cd smart
