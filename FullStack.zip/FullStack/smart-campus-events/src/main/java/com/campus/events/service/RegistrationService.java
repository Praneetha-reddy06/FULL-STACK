package com.campus.events.service;

import com.campus.events.entity.Registration;
import com.campus.events.repository.RegistrationRepository;
import com.campus.events.repository.EventRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class RegistrationService {
    
    @Autowired
    private RegistrationRepository registrationRepository;
    
    @Autowired
    private EventRepository eventRepository;
    
    public Registration registerForEvent(Registration registration) {
        // Check if event has capacity
        Long eventId = registration.getEvent().getId();
        Long count = registrationRepository.countByEventId(eventId);
        if (count >= registration.getEvent().getCapacity()) {
            throw new RuntimeException("Event is full");
        }
        
        Registration saved = registrationRepository.save(registration);
        
        // Update event registration count
        eventRepository.incrementRegistrationCount(eventId);
        
        return saved;
    }
    
    public List<Registration> getRegistrationsByEmail(String email) {
        return registrationRepository.findByStudentEmail(email);
    }
    
    public List<Registration> getRegistrationsByEventId(Long eventId) {
        return registrationRepository.findByEventId(eventId);
    }
    
    public Long getEventRegistrationCount(Long eventId) {
        return registrationRepository.countByEventId(eventId);
    }
    
    public Long getTotalRegistrations() {
        return registrationRepository.count();
    }
}

