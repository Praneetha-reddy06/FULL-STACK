package com.campus.events.controller;

import com.campus.events.entity.Event;
import com.campus.events.service.EventService;
import com.campus.events.service.RegistrationService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {
    
    @Autowired
    private EventService eventService;
    
    @Autowired
    private RegistrationService registrationService;
    
    @GetMapping
    public String adminDashboard(Model model) {
        model.addAttribute("totalRegistrations", registrationService.getTotalRegistrations());
        model.addAttribute("totalEvents", eventService.getAllEvents().size());
        return "admin/events";
    }
    
    @GetMapping("/events")
    public String events(@RequestParam(required = false) String department,
                        @RequestParam(required = false) String type,
                        @RequestParam(required = false) String dateFrom,
                        @RequestParam(required = false) String dateTo,
                        @RequestParam(required = false) String title,
                        Model model) {
        LocalDateTime minDate = null, maxDate = null;
        if (dateFrom != null && !dateFrom.isEmpty()) {
            minDate = LocalDateTime.parse(dateFrom + "T00:00", DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm"));
        }
        if (dateTo != null && !dateTo.isEmpty()) {
            maxDate = LocalDateTime.parse(dateTo + "T23:59", DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm"));
        }
        List<Event> events = eventService.searchEvents(department, type, minDate, maxDate, title);
        model.addAttribute("events", events);
        model.addAttribute("searchParams", new SearchParams());
        model.addAttribute("departments", List.of("CSE", "ECE", "MECH", "CIVIL", "MBA"));
        model.addAttribute("types", List.of("Workshop", "Seminar", "Conference", "Cultural"));
        return "admin/events";
    }
    
    @GetMapping("/events/new")
    public String newEvent(Model model) {
        model.addAttribute("event", new Event());
        return "admin/add-event";
    }
    
    @PostMapping("/events")
    public String createEvent(@Valid @ModelAttribute Event event, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "admin/add-event";
        }
        eventService.saveEvent(event);
        return "redirect:/admin/events";
    }
    
    @GetMapping("/events/{id}/edit")
    public String editEvent(@PathVariable Long id, Model model) {
        Event event = eventService.getEventById(id);
        if (event == null) {
            return "redirect:/admin/events";
        }
        model.addAttribute("event", event);
        return "admin/edit-event";
    }
    
    @PostMapping("/events/{id}")
    public String updateEvent(@PathVariable Long id, @Valid @ModelAttribute Event event, BindingResult result) {
        if (result.hasErrors()) {
            return "admin/edit-event";
        }
        event.setId(id);
        eventService.saveEvent(event);
        return "redirect:/admin/events";
    }
    
    @PostMapping("/events/{id}/delete")
    public String deleteEvent(@PathVariable Long id) {
        eventService.deleteEvent(id);
        return "redirect:/admin/events";
    }
    
    @GetMapping("/statistics")
    public String statistics(Model model) {
        model.addAttribute("totalRegistrations", registrationService.getTotalRegistrations());
        // Add more stats
        return "admin/statistics";
    }
    
    static class SearchParams {
        // Helper class for search form binding
    }
}

