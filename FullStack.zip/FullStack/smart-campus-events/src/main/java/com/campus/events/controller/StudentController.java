package com.campus.events.controller;

import com.campus.events.entity.Registration;
import com.campus.events.service.EventService;
import com.campus.events.service.RegistrationService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/student")
public class StudentController {
    
    @Autowired
    private EventService eventService;
    
    @Autowired
    private RegistrationService registrationService;
    
    @GetMapping("/events")
    public String events(Model model) {
        model.addAttribute("events", eventService.getUpcomingEvents());
        model.addAttribute("availableEvents", eventService.getAvailableEvents());
        return "student/events";
    }
    
    @GetMapping("/event/{id}/register")
    public String showRegistrationForm(@PathVariable Long id, Model model, HttpSession session) {
        var event = eventService.getEventById(id);
        if (event == null || event.isFull()) {
            return "redirect:/student/events";
        }
        model.addAttribute("event", event);
        if (session.getAttribute("studentEmail") != null) {
            model.addAttribute("email", session.getAttribute("studentEmail"));
        }
        model.addAttribute("registration", new Registration());
        return "student/register";
    }
    
    @PostMapping("/event/{id}/register")
    public String register(@PathVariable Long id, @Valid @ModelAttribute Registration registration,
                          BindingResult result, Model model, HttpSession session) {
        registration.setEvent(eventService.getEventById(id));
        
        if (result.hasErrors()) {
            model.addAttribute("event", registration.getEvent());
            return "student/register";
        }
        
        try {
            registrationService.registerForEvent(registration);
            session.setAttribute("studentEmail", registration.getStudentEmail());
            session.setAttribute("successMessage", "Registration successful!");
            return "redirect:/student/events";
        } catch (Exception e) {
            result.rejectValue("studentEmail", "error.registration", e.getMessage());
            model.addAttribute("event", registration.getEvent());
            return "student/register";
        }
    }
    
    @GetMapping("/my-registrations")
    public String myRegistrations(HttpSession session, Model model) {
        String email = (String) session.getAttribute("studentEmail");
        if (email == null) {
            return "redirect:/student/events";
        }
        // For demo, just show recent registrations
        model.addAttribute("registrations", registrationService.getRegistrationsByEmail(email));
        return "student/my-registrations";
    }
}

