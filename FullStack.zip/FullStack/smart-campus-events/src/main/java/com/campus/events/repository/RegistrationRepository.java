package com.campus.events.repository;

import com.campus.events.entity.Registration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface RegistrationRepository extends JpaRepository<Registration, Long> {
    
    // Find by event ID
    List<Registration> findByEventId(Long eventId);
    
    // Find student registrations by email
    List<Registration> findByStudentEmail(String studentEmail);
    
    // Statistics queries
    @Query("SELECT COUNT(r) FROM Registration r WHERE r.event.id = :eventId")
    Long countByEventId(@Param("eventId") Long eventId);
    
    @Query("SELECT COUNT(DISTINCT r.studentEmail) FROM Registration r WHERE r.event.id = :eventId")
    Long countUniqueStudentsByEventId(@Param("eventId") Long eventId);
    
    // Total registrations count
    long count();
    
    // Event-wise registration count
    @Query("SELECT r.event.id, COUNT(r) FROM Registration r GROUP BY r.event.id")
    List<Object[]> getEventRegistrationCounts();
}

