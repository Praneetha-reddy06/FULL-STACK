package com.campus.events.repository;

import com.campus.events.entity.Event;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface EventRepository extends JpaRepository<Event, Long> {
    
    // Search by keyword in title/description
    List<Event> findByTitleContainingIgnoreCaseOrDescriptionContainingIgnoreCase(String title, String desc);
    
    // Filter by department and type
    List<Event> findByDepartmentAndType(String department, String type);
    
    // Filter by date range
    List<Event> findByEventDateBetween(LocalDateTime start, LocalDateTime end);
    
    // Upcoming events (future dates)
    List<Event> findByEventDateAfterOrderByEventDateAsc(LocalDateTime now);
    
    // Events with available capacity
    List<Event> findByCapacityGreaterThanRegisteredCountOrderByEventDateAsc();
    
    // Admin search: custom query with multiple filters
    @Query("SELECT e FROM Event e WHERE " +
           "(:department IS NULL OR e.department = :department) AND " +
           "(:type IS NULL OR e.type = :type) AND " +
           "(:minDate IS NULL OR e.eventDate >= :minDate) AND " +
           "(:maxDate IS NULL OR e.eventDate <= :maxDate) AND " +
           "(:title IS NULL OR LOWER(e.title) LIKE LOWER(CONCAT('%', :title, '%')))")
    List<Event> searchEvents(@Param("department") String department,
                           @Param("type") String type,
                           @Param("minDate") LocalDateTime minDate,
                           @Param("maxDate") LocalDateTime maxDate,
                           @Param("title") String title);
}

