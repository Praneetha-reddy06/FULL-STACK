package com.campus.events.service;

import com.campus.events.entity.Event;
import com.campus.events.repository.EventRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class EventService {
    
    @Autowired
    private EventRepository eventRepository;
    
    public List<Event> getAllEvents() {
        return eventRepository.findAll();
    }
    
    public List<Event> getUpcomingEvents() {
        return eventRepository.findByEventDateAfterOrderByEventDateAsc(LocalDateTime.now());
    }
    
    public List<Event> getAvailableEvents() {
        return eventRepository.findByCapacityGreaterThanRegisteredCountOrderByEventDateAsc();
    }
    
    public Event getEventById(Long id) {
        return eventRepository.findById(id).orElse(null);
    }
    
    public Event saveEvent(Event event) {
        return eventRepository.save(event);
    }
    
    public void deleteEvent(Long id) {
        eventRepository.deleteById(id);
    }
    
    public List<Event> searchEvents(String department, String type, LocalDateTime minDate, LocalDateTime maxDate, String title) {
        return eventRepository.searchEvents(department, type, minDate, maxDate, title);
    }
    
    public void incrementRegistrationCount(Long eventId) {
        Event event = getEventById(eventId);
        if (event != null) {
            event.setRegisteredCount(event.getRegisteredCount() + 1);
            saveEvent(event);
        }
    }
}

