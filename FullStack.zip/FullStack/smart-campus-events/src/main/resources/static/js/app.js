// Client-side JavaScript for Smart Campus Events

document.addEventListener('DOMContentLoaded', function() {
    // Form validation
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!this.checkValidity()) {
                e.preventDefault();
                e.stopPropagation();
            }
            this.classList.add('was-validated');
        });
    });
    
    // Confirmation dialogs
    const deleteForms = document.querySelectorAll('form[method="post"]');
    deleteForms.forEach(form => {
        if (form.querySelector('button[type="submit"]')?.textContent.includes('Delete')) {
            form.onsubmit = function() {
                return confirm('Are you sure you want to delete this event?');
            };
        }
    });
    
    // Auto-hide alerts
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });
});

