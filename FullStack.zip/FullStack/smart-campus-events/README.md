# Smart Campus Event Management System

## Full Stack Spring Boot Project

### Features
- **Student Side**: Browse events, register with validation, view registrations
- **Admin Side**: CRUD operations, search/filter events (date, dept, type), statistics
- **Tech Stack**: Spring Boot 3.2, Spring MVC, JPA/Hibernate, Thymeleaf, H2 DB, Spring Security, Bootstrap 5

### Quick Start
```bash
cd smart-campus-events
mvn spring-boot:run
```

**Access**:
- Main: http://localhost:8080
- Student Events: http://localhost:8080/student/events  
- Admin: http://localhost:8080/admin (admin/admin123)
- H2 Console: http://localhost:8080/h2-console

### Technical Highlights
✅ **Spring Core**: `@Autowired` DI, Bean management  
✅ **Spring MVC**: `@Controller`, `@RequestMapping`  
✅ **Spring Boot**: Embedded Tomcat, REST APIs  
✅ **Spring Data JPA**: `@Entity`, `@Repository`, custom JPQL queries  
✅ **Validation**: `@NotNull`, `@Size`, `@Email`, `@FutureOrPresent`  
✅ **Security**: Basic auth + form login for admin  
✅ **Exception Handling**: `@ControllerAdvice`  
✅ **Frontend**: Thymeleaf + HTML5/CSS3 + Bootstrap + JS validation

### Sample Usage
1. Admin creates events (CSE Workshop, ECE Seminar, etc.)
2. Students browse/register (validation prevents over-capacity)
3. Admin views stats, searches with filters
4. Data persists in H2 (view in H2 Console)

**All requirements fulfilled as per project specification!**

