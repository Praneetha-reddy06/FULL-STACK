# MySQL Integration TODO

✅ [DONE] Plan approved and TODO created  
✅ [DONE] Update pom.xml with MySQL dependency  
✅ [DONE] Update application.properties for MySQL  
✅ [DONE] Files updated successfully  
✅ [DONE] Maven build prepared (run manually if needed: cd smart-campus-events && ./mvnw.cmd clean install)  
⚠️  [REQUIRED] Ensure MySQL server running (localhost:3306)  
⚠️  [REQUIRED] Create DB: mysql -u root -p -e "CREATE DATABASE IF NOT EXISTS campus_events;" (pass: root)  
- [ ] Start app: cd smart-campus-events && ./mvnw.cmd spring-boot:run  
- [ ] Test: Open http://localhost:8080 in browser  
✅ [DONE] MySQL connection configured
